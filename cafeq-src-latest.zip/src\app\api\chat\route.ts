import { NextRequest, NextResponse } from 'next/server'

const rateLimitMap = new Map<string, { count: number; resetAt: number }>()
function checkRateLimit(ip: string): boolean {
  const now = Date.now()
  const entry = rateLimitMap.get(ip)
  if (!entry || now > entry.resetAt) { rateLimitMap.set(ip, { count: 1, resetAt: now + 60_000 }); return true }
  if (entry.count >= 20) return false
  entry.count++; return true
}

export async function POST(req: NextRequest) {
  const ip = req.headers.get('x-forwarded-for') || 'unknown'
  if (!checkRateLimit(ip)) {
    return NextResponse.json({ choices: [{ message: { content: 'Too many requests. Please wait a minute.' } }], items: [] }, { status: 429 })
  }

  const apiKey = process.env.GROQ_API_KEY || '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'

  try {
    const body = await req.json()
    const { messages, menuContext, slotContext } = body
    if (!Array.isArray(messages) || messages.length === 0) {
      return NextResponse.json({ choices: [{ message: { content: 'Invalid request.' } }], items: [] }, { status: 400 })
    }

    const trimmedMessages = messages.slice(-10)
    const lastUserMsg = [...trimmedMessages].reverse().find((m: any) => m.role === 'user')?.content || ''

    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${apiKey}` },
      body: JSON.stringify({
        model: 'llama-3.3-70b-versatile',
        max_tokens: 500,
        messages: [
          {
            role: 'system',
            content: `You are CafeQ cafe assistant.
Menu items available: ${menuContext}
Slots: ${slotContext}

LANGUAGE RULES:
1. DEFAULT language is ENGLISH. If unsure, always use English.
2. NEVER use Hindi unless user writes in Hindi Devanagari script or says "Hindi mein batao".
3. The user's last message is: "${lastUserMsg}"
4. Detect language: English words → English. Gujarati Roman (avak, ketlu, kem cho, thai, mahino) → Gujarati script. Hindi Devanagari → Hindi. Tamil/Telugu/Kannada etc → that language. Mixed/unclear → English.
5. English input = English output always.

When recommending food items, ALWAYS end with:
ITEMS_JSON:[{"name":"Samosa","price":20}]
If no items: ITEMS_JSON:[]
Give a friendly short answer with emojis before the JSON.`,
          },
          { role: 'assistant', content: 'Hello! I am your CaféQ assistant. Ask me anything!' },
          ...trimmedMessages,
        ],
      }),
    })

    const text = await response.text()
    const data = JSON.parse(text)
    const raw = data.choices?.[0]?.message?.content || 'Sorry, try again!'
    const jsonMatch = raw.match(/ITEMS_JSON:(\[[\s\S]*?\])/)
    let items: unknown[] = []
    let reply = raw
    if (jsonMatch) {
      try { items = JSON.parse(jsonMatch[1]) as unknown[]; reply = raw.replace(/ITEMS_JSON:\[[\s\S]*?\]/, '').trim() }
      catch { items = [] }
    }
    return NextResponse.json({ choices: [{ message: { content: reply } }], items })
  } catch (err) {
    console.error('ERR:', err)
    return NextResponse.json({ choices: [{ message: { content: 'Something went wrong. Please try again.' } }], items: [] })
  }
}